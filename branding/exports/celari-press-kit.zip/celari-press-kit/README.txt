Celari Press Kit

Contents:
  /svg/         Original logo + wordmark SVG sources (vector, scalable)
  /png/         Rasterized 256/512/1024 PNGs for each variant
  /app-icon/    1024×1024 app icon masters (dark / light)
  BRAND-COLORS.txt   Color + typography reference

Permitted uses:
  - Press, partner integration, app store listings, social media
  - Articles, videos, presentations referencing Celari
  - Documentation and tutorials covering Celari Wallet

Not permitted:
  - Implying endorsement or partnership without prior written approval
  - Modifying the logo geometry, colors, or wordmark spacing
  - Using on backgrounds that obscure the mark (use the mono variants
    where contrast is poor)

Contact:
  https://celariwallet.com
